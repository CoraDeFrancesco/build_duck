# build_duck
Add a duck marker to Matplotlib.

# Example
import build_duck

duck_marker = build_duck()

plt.plot(x, y, marker=duck_marker)
